import pandas as pd 

def limpiar_deportistas(df):
    df.columns = df.columns.str.lower().str.strip()
    
    if 'deporte' in df.columns:
        df['deporte'] = df['deporte'].str.lower().str.strip()
        df['deporte'] = df['deporte'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode('utf-8')
    
    if 'peso_kg' in df.columns:
        df['peso_kg'] = df['peso_kg'].astype(str).str.replace(',', '.').astype(float)
    
    if 'horas_entrenamiento_semana' in df.columns:
        df['horas_entrenamiento_semana'] = df['horas_entrenamiento_semana'].astype(str).str.replace(',', '.').astype(float)
        
    cols_numericas = ['edad', 'peso_kg', 'altura_cm', 'frecuencia_cardiaca_bpm', 'horas_entrenamiento_semana', 'rendimiento_score']
    for col in cols_numericas:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            
    df = df.drop_duplicates()
    
    for col in ['peso_kg', 'horas_entrenamiento_semana']:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        limite_inferior = Q1 - 1.5 * IQR
        limite_superior = Q3 + 1.5 * IQR
        
        df = df[(df[col] >= limite_inferior) & (df[col] <= limite_superior) | df[col].isnull()]
        
    for col in cols_numericas:
        if col in df.columns:
            media = df[col].mean()
            df[col] = df[col].fillna(media)
            
    return df