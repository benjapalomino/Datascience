import pandas as pd

def Resumen_datos(df):
    """1. Retorna total de deportistas, promedio de rendimiento y edad promedio"""
    total_deportistas = len(df)
    promedio_rendimiento = df['rendimiento_score'].mean()
    edad_promedio = df['edad'].mean()
    
    return {
        'Total_deportistas': total_deportistas,
        'Promedio_rendimiento': promedio_rendimiento,
        'Edad_promedio': edad_promedio
    }

def Promedio_por_deporte(df):
    """2. Retorna el promedio de rendimiento agrupado por disciplina"""
    if 'deporte' in df.columns and 'rendimiento_score' in df.columns:
        return df.groupby('deporte')['rendimiento_score'].mean().reset_index()
    return pd.DataFrame()

def Deportistas_destacados(df):
    """3. Filtra deportistas con rendimiento_score mayor a 7.0"""
    if 'rendimiento_score' in df.columns:
        return df[df['rendimiento_score'] > 7.0]
    return pd.DataFrame()