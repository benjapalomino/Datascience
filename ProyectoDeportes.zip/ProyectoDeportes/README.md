🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱
ProyectoDeportes/
├── data/
│   └── deportistas.csv            # Dataset original
├── notebooks/
│   └── analisis.ipynb             # Notebook principal con la ejecución del flujo
├── outputs/
│   ├── deportistas_limpios.csv    # Datos procesados y limpios
│   └── analisis_por_deporte.csv   # Resultados del análisis agrupado
├── src/
│   ├── __init__.py                # Inicializador de módulo
│   ├── limpieza.py                # Lógica de limpieza y preprocesamiento
│   └── analisis.py                # Funciones de cálculo y agregación
└── README.md                      # Documentación del proyecto
🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱🧱

Paso a Paso Realizado 🛠️

🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭
1. Exploración Inicial
Se cargó el archivo deportistas.csv identificando problemas críticos:

Inconsistencias en nombres de columnas (espacios y mayúsculas).

Formatos numéricos incorrectos (uso de comas en decimales).

Presencia de valores nulos en columnas clave como peso_kg y horas_entrenamiento.

Registros duplicados y valores atípicos (outliers).

🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭🧭

(notebook (1))
🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️🗑️
2. Limpieza de Datos (src/limpieza.py)
Se implementó la función limpiar_deportistas(df) que ejecuta:

Normalización: Columnas y categorías de deportes pasadas a minúsculas y sin tildes.

Conversión: Transformación de strings con comas a floats de Python.

Outliers: Eliminación de registros fuera del rango 1.5 * IQR en peso y entrenamiento.

Imputación: Relleno de valores nulos utilizando la media aritmética de cada columna.
🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹🧹

🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬
3. Análisis de Datos (src/analisis.py)
Se desarrollaron funciones para extraer insights:

Resumen General: Conteo total, promedio de rendimiento y edad.

Agrupación: Rendimiento promedio por disciplina deportiva.

Filtrado: Identificación de deportistas destacados (Score > 7.0).
🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬🧑‍🔬

📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕

lenguajes utilizados

Python 3.x

Pandas

IPython (para visualización en Notebooks)
📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕📕
Nota: Este proyecto fue desarrollado para la asignatura de Ingeniería en Informática con especialidad en Ciencia de Datos en Duoc UC.
autor : Benjamin palomino